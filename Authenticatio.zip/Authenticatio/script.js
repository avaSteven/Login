// Google Authentication
const googleLoginButton = document.getElementById('google-login');
googleLoginButton.addEventListener('click', () => {
  const provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider)
    .catch(error => {
      displayErrorMessage(error.message);
    });
});

// Facebook Authentication
const facebookLoginButton = document.getElementById('facebook-login');
facebookLoginButton.addEventListener('click', () => {
  const provider = new firebase.auth.FacebookAuthProvider();
  firebase.auth().signInWithPopup(provider)
    .catch(error => {
      displayErrorMessage(error.message);
    });
});

// GitHub Authentication
const githubLoginButton = document.getElementById('github-login');
githubLoginButton.addEventListener('click', () => {
  const provider = new firebase.auth.GithubAuthProvider();
  firebase.auth().signInWithPopup(provider)
    .catch(error => {
      displayErrorMessage(error.message);
    });
});

// OTP Authentication
const phoneAuthContainer = document.getElementById('phone-auth-container');
const phoneNumberInput = document.getElementById('phone-number');
const sendOtpButton = document.getElementById('send-otp');
const verificationCodeInput = document.getElementById('verification-code');
const verifyOtpButton = document.getElementById('verify-otp');

sendOtpButton.addEventListener('click', () => {
  const phoneNumber = phoneNumberInput.value;
  const appVerifier = new firebase.auth.RecaptchaVerifier('send-otp', {
    size: 'invisible',
  });

  firebase.auth().signInWithPhoneNumber(phoneNumber, appVerifier)
    .then(confirmationResult => {
      const verificationId = confirmationResult.verificationId;
      sendOtpButton.disabled = true;
      verificationCodeInput.disabled = false;
      verifyOtpButton.disabled = false;

      verifyOtpButton.addEventListener('click', () => {
        const verificationCode = verificationCodeInput.value;
        const credential = firebase.auth.PhoneAuthProvider.credential(verificationId, verificationCode);
        firebase.auth().signInWithCredential(credential)
          .catch(error => {
            displayErrorMessage(error.message);
          });
      });
    })
    .catch(error => {
      displayErrorMessage(error.message);
    });
});

// Display error message
function displayErrorMessage(message) {
  const errorMessageElement = document.getElementById('error-message');
  errorMessageElement.textContent = message;
}
